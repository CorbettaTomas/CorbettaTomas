import "./styles.css";
const multiplier: number = Number(prompt("Quiero la tabla del..."));
const limit: number = Number(prompt("Multiplicar hasta el..."));

for(let i: number = 1; i <= limit; i++) {
  console.log(`${multiplier} x ${i} = ${multiplier * i}`);
}

//let userInput: number = Number(prompt("Ingrese un número. Cero para:"));
//let maxNum: number = userInput;
//let noInitialZero: boolean = false

//while(userInput != 0) {
 // noInitialZero = true
  //userInput = Number(prompt("Ingrese un número:"));
  //if (userInput > maxNum) {
   // maxNum = userInput;
 // }
//}
//if(userInput === 0){
 // console.log("termino sin datos...")
//} else {
 // console.log("el numero mas grande", maxNum)
//}
//if (noInitialZero){console.log(`el numero mas grande es: ${maxNum}`)
//}