import "./styles.css";
/*
Escriba un programa que pida al usuario dos numeros enteros, y luego retorne la suma de todos
los numeros que estan entre ellos
.
Por ejemplo, si los numeros son 2 y 7, debe entregar como resultado 2 + 3 + 4 + 5 + 6 + 7 = 27
*/
let numInit: number = Number(/prompt("Numero Inicial"));
let numEnd: number = Number(/prompt("Numero Final"));
// let counter: number = numInit;
let accum: number = 0;

// while (counter <= numEnd) {
//   accum = accum + counter;
//   //pintas en dom el valor de counter
//   counter++;  
// }
if(numInit > numEnd){
  let aux:number = numInit;
  numEnd = numInit;
  numEnd = aux;

}

for (let i: number = numInit; <= numEnd; i++){
  accum = accum + i;
}
console.log(`la suma del rango es: ${accum}.`);